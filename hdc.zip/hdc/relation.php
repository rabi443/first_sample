create relation between these tables for online voting system in college.
1.students_batch_and_roll_number(batch,roll_number),
2.students(full_name,mobile_number,gmail,student_status,gender,roll_number,semester,batch),
3.candidates(semester,roll_no,full_name,mobile_number,votes,candidate_status),
4.candidate_form(semester,form_status),
5.vote_result(result_status,semester)


////


Based on the defined primary and foreign keys, here are the attributes for each table in the online voting system:

### 1. **students_batch_and_roll_number**
- **Attributes**:
  - `batch` (Primary Key component)
  - `roll_number` (Primary Key component)

### 2. **students**
- **Attributes**:
  - `full_name`
  - `mobile_number`
  - `gmail`
  - `student_status`
  - `gender`
  - `roll_number` (Primary Key)
  - `semester`
  - `batch` (Foreign Key referencing `students_batch_and_roll_number.batch`)

### 3. **candidates**
- **Attributes**:
  - `semester` (Primary Key component and Foreign Key referencing `candidate_form.semester`)
  - `roll_no` (Primary Key component and Foreign Key referencing `students.roll_number`)
  - `full_name`
  - `mobile_number`
  - `votes`
  - `candidate_status`

### 4. **candidate_form**
- **Attributes**:
  - `semester` (Primary Key)
  - `form_status`

### 5. **vote_result**
- **Attributes**:
  - `semester` (Primary Key)
  - `result_status`

### Summary of Table Attributes:

| Table                          | Attributes                                                                                      |
|--------------------------------|--------------------------------------------------------------------------------------------------|
| **students_batch_and_roll_number** | `batch`, `roll_number` (Primary Key)                                                             |
| **students**                   | `full_name`, `mobile_number`, `gmail`, `student_status`, `gender`, `roll_number` (Primary Key), `semester`, `batch` (Foreign Key) |
| **candidates**                 | `semester` (Primary Key), `roll_no` (Primary Key), `full_name`, `mobile_number`, `votes`, `candidate_status` (Foreign Key) |
| **candidate_form**             | `semester` (Primary Key), `form_status`                                                         |
| **vote_result**                | `semester` (Primary Key), `result_status`                                                        |

### Explanation:
- **students_batch_and_roll_number**: This table serves as a lookup table for batch and roll number, so it only needs these two attributes as a composite key.
- **students**: Contains detailed student information and links to the `students_batch_and_roll_number` table via `batch` and `roll_number`.
- **candidates**: Identifies candidates and tracks their status and votes. It links to `students` for student details and to `candidate_form` for the election form status.
- **candidate_form**: Stores the status of candidate forms for each semester.
- **vote_result**: Stores the result status for each semester's election.

By defining attributes and relationships this way, you ensure that the database schema supports the functionality of the online voting system efficiently and maintains data integrity.