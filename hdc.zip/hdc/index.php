<?php
if(!((include_once "header_footer/header.html")and
(include_once "assets/login.html")and
(include_once "header_footer/footer.html"))
){
    echo"Something is wrong with your code :-(";
}
?>
