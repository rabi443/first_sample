<?php
    $check = mail("rabinchy54321@gmail.com","HDC voting system.","This is your code:12345","From:rc2583463@gmail.com");

    if($check){
        echo"Email Sent successfully.";
    }else{
        echo"Nework error...";
    }

?>