<?php
include_once("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot_password</title>
    <link rel="stylesheet" href="../../css/login.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/body.css">
</head>
<body>
<?php 
        // include_once("../../header_footer/header.html");
        //check the method of form is post or not
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            $mobile_number=$_POST['mobile_number'];
            $roll_no=$_POST['roll_no'];

            $sql="SELECT password FROM students
            WHERE roll_no='$roll_no' AND mobile_number='$mobile_number' ";
            
            $result=mysqli_query($db_bim,$sql);
            if(mysqli_num_rows($result)>0){

                echo '
                <div style="text-align:center; margin-top:5px;">
                    <img src="../../upload_files/hdc.png" alt="HDC">
                    <form name="myform" action="forgot_password2.php" method="POST" style="margin-top:5%; width:22%;border-radius:5px;border:1px solid black; margin-left: 38%; background: #fff;">
                        <h3>Choose New password</h3>
                        <input type="hidden" name="mobile_number" placeholder="Enter mobile number" id="mobile_number" value="'.$mobile_number.'" >
                        <input type="hidden" name="roll_no" placeholder="Enter roll_no" id="roll_no" value="'.$roll_no.'">
                        <input type="password" name="new_password" placeholder="New password" id="new_password"><br><br>
                        <input type="password" name="confirm_new_password" placeholder="Confirm password" id="confirm_new_password"><br><br>
                        <button name="change" value="true" onclick="return validate()" style="background-color: rgb(27, 48, 139); border-radius: 2px; width:50%;">change password</button><br><br>
                        <a href="../../index.php" style=" text-decoration: none; color: blue; font-size: larger;">cancel</a><br><br><br>
                    </form>  
                </div>
                ';
            }
            else{
                echo" 
                <script>
                    alert('Mobile_no $mobile_number and roll_no $roll_no doesnot exist.Sorry!');
                    window.location.href='../../index.php';
                </script>
                ";
            }
        }
        // include_once("../../header_footer/footer.html");
    ?>
    
</body>
</html>


