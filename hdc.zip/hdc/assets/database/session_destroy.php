<?php
    include_once("connection.php");
    session_start();
    if(isset($_SESSION['student_data'])){

        unset($_SESSION['student_data']);
       
        // // remove all session variables
        // session_unset();

        // // destroy the session
        // session_destroy();

        header('location:dashboard.php');

    }
?>