<?php
    include_once("connection.php");
    
    session_start();
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students</title>
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/body.css">
    <link rel="stylesheet" href="../../css/dashboard.css">
    
    <style>
        #submit-button{
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }
        ul{
            
            margin-left:10%;
            margin-right:10%;
        }
        
        li{
            background: #fff;
            border-radius:none;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>
<body style="margin:0px;">

    <div id="top-section">
        <header>
        <!-- <img src="../../upload_files/hdc.png" alt="HDC"> -->
            <h1>Digital Election Platform</h1>
            
        </header>
    </div>

    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px;text-align: center; box-sizing: border-box;">
        <nav>  
            <a href="dashboard.php">Home</a>
            <a href="candidates.php">Candidates</a>
            <a href="result.php">Result</a>
            <a href="inbox.php"  style="color: rgb(172, 166, 214);">Students</a>
            <!-- <a href="about_us.php" >About us</a> -->
            <!-- <button onclick="window.location.href='dashboard.php'" style="float:left;">back</button>  -->
            <button onclick="window.location.href='session_destroy.php'" style="float:right;">Log out</button>
        </nav>
    </div> 


    <div style='width:85%; background-color:#fff; margin-left:7.5%; padding:20px;'>
        <?php
        //STUDENTS LIST

            if($_SESSION['student_data']['semester']=='First'){

                $students_sql="SELECT * FROM students WHERE semester='First'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
            }

            if($_SESSION['student_data']['semester']=='Second'){

                $students_sql="SELECT * FROM students WHERE semester='Second'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
            }

            if($_SESSION['student_data']['semester']=='Third'){

                $students_sql="SELECT * FROM students WHERE semester='Third'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
                
            }

            if($_SESSION['student_data']['semester']=='Fourth'){

                $students_sql="SELECT * FROM students WHERE semester='Fourth'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
                
            }

            if($_SESSION['student_data']['semester']=='Fifth'){

                $students_sql="SELECT * FROM students WHERE semester='Fifth'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
                
            }

            if($_SESSION['student_data']['semester']=='Sixth'){

                $students_sql="SELECT * FROM students WHERE semester='Sixth'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
                
            }

            if($_SESSION['student_data']['semester']=='Seventh'){

                $students_sql="SELECT * FROM students WHERE semester='Seventh'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
                
            }

            if($_SESSION['student_data']['semester']=='Eighth'){

                $students_sql="SELECT * FROM students WHERE semester='Eighth'";
                $all_students=mysqli_query($db_bim,$students_sql);
    
                if($all_students){
                    if(mysqli_num_rows($all_students)>0){
                      
                        $i = 1;
    
                        echo "
                        <table style='border:0px solid black; background-color:white; margin-top:10px; padding:10px; border-spacing: 20px; border-collapse: separate;width:80%;margin-left:10%;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <tr style='background-color:;color:black; text-align:left;'>
                                        <th>S.N</th><th>Frist name</th><th>Middle name</th><th>Last name</th><th>Address</th><th>Gmail_address</th>
                                    </tr>
                        ";
                        while ($students_array = mysqli_fetch_assoc($all_students)) {
                            echo "
                                    <tr style='box-shadow: 0px 0px 0px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                       <td>$i</td> <td>" .htmlspecialchars($students_array['first_name']) ."</td><td>" . htmlspecialchars($students_array['middle_name']) . "</td><td>" . htmlspecialchars($students_array['last_name']). "</td><td>" . htmlspecialchars($students_array['address']) ."</td><td>" . htmlspecialchars($students_array['gmail']) ."</td>
                                    </tr>
                                ";
                            $i++;
                        }
                        echo " </table>";
                    }else{
                        echo"<h3>No any students are available.</h3>";
                    }
                }
                
            }
        ?>

    
    </div>
    
    <div id="footer-section">
        <footer>
            Copyright © 2024, All rights reserved. <a>The Constructors.</a>
        </footer>
    </div>

    <script>
    // JavaScript to make navbar fixed when it reaches the top of the page
    window.onscroll = function() {fixNavbar()};

    var navbar = document.getElementById("navbar");
    var sticky = navbar.offsetTop;

    function fixNavbar() {
        if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky");
        } else {
        navbar.classList.remove("sticky");
        }
    }
    </script>

</body>
</html>