<?php

    include_once("connection.php");
    session_start();
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User profile</title>
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/body.css">
    <style>
        
        li {
            margin-bottom: 15px;
            padding: 10px;
            background: #fff;
            border:1px solid black;
            
            
        }
        ul{
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            width:60%;
            margin-left:20%;
        }
        .container{
            align-item:center;
            justify-content:center;
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>

<body>
   
    <!--<img src="../../upload_files/<?php echo $_SESSION['student_data']['profile_photo'] ?>" alt="profile photo" style="width:100px; height:120px;">-->
    <div id="top-section">
        <header>
            <!-- <img src="../../upload_files/hdc.png" alt="HDC"> -->
            <h1>Digital Election Platform</h1>
            
        </header>
    </div>
    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115);padding: 15px;text-align: center; ">
        <nav>
            <a href="dashboard.php">Home</a>
            <a href="candidates.php">Candidates</a>
            <a href="result.php">Result</a>
            <a href="inbox.php">Students</a>
            <!-- <a href="about_us.php">About us</a> -->
            <button onclick="window.location.href='dashboard.php'" style="float:left;">back</button> 
            <button onclick="window.location.href='session_destroy.php'" style="float:right;">Log out</button>
        </nav>
    </div> 

    <div class="container">
        <!-- <div style="text-align:center;">
            <img src="../../upload_files/hdc.png" alt="HDC">
        </div> -->
        <ul>
            <div style="text-align:center;"><h2 class="title"><u>User profile</u></h2></div>
            <img src="../../upload_files/<?php echo $_SESSION['student_data']['profile_photo'] ?>" alt="profile photo" style="width:90px; height:80px; border-radius:1%;box-sizing: border-box;">
            <!-- <button onclick="window.location.href='#'" style="background-color:black; border-radius:5px; margin-top:50px;"><img src="../../upload_files/OIP (2).jpeg" alt="change_profile" style="height:15px; width:15px;"></button><br>
            --><li> 
                <b>First_Name</b> : <?php echo $_SESSION['student_data']['first_name'] ?><br>
            </li>
            <li>
                <b>Last_Name</b> : <?php echo $_SESSION['student_data']['last_name'] ?><br>
            </li>
            <li>
                <b>Middle_Name</b> : <?php echo $_SESSION['student_data']['middle_name'] ?><br>
            </li>
            <li>
                <b>Mobile_no</b> : <?php echo $_SESSION['student_data']['mobile_number'] ?><button onclick="window.location.href='#'">edit</button><br>
            </li>
            <li>
                <b>gmail</b> : <?php echo $_SESSION['student_data']['gmail'] ?><button onclick="window.location.href='#'">edit</button><br>
            </li>
            <li>
            <b>Address</b> : <?php echo $_SESSION['student_data']['address'] ?><br>
            </li>
            <li>
                <b>Program</b> : <?php echo $_SESSION['student_data']['program'] ?><br>
            </li>
            <li>
                <b>Semester</b> : <?php echo $_SESSION['student_data']['semester'] ?><button onclick="window.location.href='#'">edit</button><br>
            </li>
            <li>
                <b>Batch</b> : <?php echo $_SESSION['student_data']['batch'] ?><br>
            </li>
            <li>
                <b>Role</b> : <?php echo $_SESSION['student_data']['role'] ?><br>
            </li>
            <li>
                <b>Roll_no</b> : <?php echo $_SESSION['student_data']['roll_no'] ?><br>
            </li>
            <li>
                <b>DOB</b> : <?php echo $_SESSION['student_data']['dob'] ?><br>
            </li>
            <li>
                <b>Status</b> : <?php if( ($_SESSION['student_data']['status'])==1){echo"voted";} ?><br>
            </li>
        </ul>   
    </div>
    <div>
        <?php
            include_once ("../../header_footer/footer.html");
        ?>
    </div>
    <script>
                    // JavaScript to make navbar fixed when it reaches the top of the page
                    window.onscroll = function() {fixNavbar()};

                    var navbar = document.getElementById("navbar");
                    var sticky = navbar.offsetTop;

                    function fixNavbar() {
                        if (window.pageYOffset >= sticky) {
                        navbar.classList.add("sticky");
                        } else {
                        navbar.classList.remove("sticky");
                        }
                    }
                </script>
</body>
</html>