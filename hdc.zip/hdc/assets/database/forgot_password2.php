<?php
include_once("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot_password</title>
</head>
<body>
    <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $new_password=$_POST['new_password'];
            $confirm_new_password=$_POST['confirm_new_password'];
            $mobile_number=$_POST['mobile_number'];
            $roll_no=$_POST['roll_no'];

            if($new_password===$confirm_new_password){
                            //sql querry to update password in database
                $sql1="UPDATE students
                SET password = '$new_password'
                WHERE roll_no='$roll_no' AND mobile_number='$mobile_number' ";

                $result1=mysqli_query($db_bim,$sql1);
                if($result1){
                    echo"
                    <script>
                        alert('Successfully password changed.');
                        window.location.href='../../index.php';
                    </script>
                    ";
                }   
            }
            else{
                echo" 
                <script>
                    alert('Confirm password does not match ..');
                    window.location.href='../../index.php';
                </script>
                "; 
            }



        }  
        else{
            echo '
                <script>
                    window.location.href="../password.html"; 
                </script>
            ';
        }

    ?>
</body>
</html>