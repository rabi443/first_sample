<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Score update</title>
</head>
<body>

    <?php
        include_once("connection.php");
        session_start();
        if(!isset($_SESSION['student_data'])){
           
            header('location:../../index.php');
    
        }
    
        if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            //candidates
            $vote=$_POST['vote'];
            $roll_no=$_POST['roll_no'];

            //students
            $student_status=$_SESSION['student_data']['status'];
            $mobile_number=$_SESSION['student_data']['mobile_number'];
            
            if($student_status==0){
                $sql="UPDATE candidates SET vote=vote+1 WHERE roll_no='$roll_no' AND candidate_status='approved'";
                $sql1="UPDATE students SET status='1' WHERE mobile_number='$mobile_number'";
                
                $result = mysqli_query($db_bim, $sql); 
                $result1 = mysqli_query($db_bim, $sql1);
              

                if($result1 and $result){
                    //header("Location:candidates.php");
                    $_SESSION['student_data']['status']=1;
                    echo"
                        <script>
                            alert('Thank you for voting.');
                            window.location.href = 'candidates.php';
                        </script>
                    ";    
                }
            }
            else{
                echo"
                    <script>
                        alert('You have already voted!..');
                        window.location.href = 'candidates.php';
                    </script>
                ";
            }    
        }
    ?>      
</body>
</html>