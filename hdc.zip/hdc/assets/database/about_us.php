<?php
    sleep(1);
    session_start();
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }

    include_once("connection.php");
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About_us</title>
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/body.css">
    <link rel="stylesheet" href="../../css/dashboard.css">
    
    <style>
        #submit-button{
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }
        ul{
            
            margin-left:10%;
            margin-right:10%;
        }
        
        li{
            background: #fff;
            border-radius:none;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>
<body style="margin:0px;">

    <div id="top-section">
        <header>
        <!-- <img src="../../upload_files/hdc.png" alt="HDC"> -->
            <h1>Digital Election Platform</h1>
            
        </header>
    </div>

    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px;text-align: center; box-sizing: border-box;">
        <nav>  
            <a href="dashboard.php">Home</a>
            <a href="candidates.php">Candidates</a>
            <a href="result.php">Result</a>
            <a href="inbox.php">Students</a>
            <!-- <a href="about_us.php" style="color: rgb(172, 166, 214);">About us</a> -->
            <!-- <button onclick="window.location.href='dashboard.php'" style="float:left;">back</button>  -->
            <button onclick="window.location.href='session_destroy.php'" style="float:right;">Log out</button>
        </nav>
    </div> 
    
    
    <div id="footer-section">
        <footer>
            Copyright © 2024, All rights reserved. <a>The Constructor.</a>
        </footer>
    </div>

    <script>
    // JavaScript to make navbar fixed when it reaches the top of the page
    window.onscroll = function() {fixNavbar()};

    var navbar = document.getElementById("navbar");
    var sticky = navbar.offsetTop;

    function fixNavbar() {
        if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky");
        } else {
        navbar.classList.remove("sticky");
        }
    }
    </script>

</body>
</html>