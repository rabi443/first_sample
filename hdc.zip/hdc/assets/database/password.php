<?php
    include_once("connection.php");

    session_start();
    
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }

    //check the method of form is post or not
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $old_password=$_POST['old_password'];
        $new_password=$_POST['new_password'];
        $confirm_new_password=$_POST['confirm_new_password'];

        //getting the roll no  and mobile number of user from database through session
        $roll_no= $_SESSION['student_data']['roll_no'];
        $mobile_number=$_SESSION['student_data']['mobile_number'];

        //sql querry to update password in database
        $sql="UPDATE students SET password = '$new_password' WHERE roll_no='$roll_no' AND mobile_number='$mobile_number' ";
        // $sql1="UPDATE fifth_sem SET password = '$new_password' WHERE roll_no='$roll_no' AND mobile_number='$mobile_number' ";
        $roll_no=$_SESSION['student_data']['roll_no'];
        $sql3="SELECT password FROM students WHERE roll_no='$roll_no'";
        $result=mysqli_query($db_bim,$sql3);
        if($result){
            if(mysqli_num_rows($result)>0){
                $row=mysqli_fetch_array($result);
                if($row['password']!=$old_password){
                    echo '
                    <script>
                        alert("old password incorrect!");
                        window.location.href="../password.html";
                    </script>
                ';
                return false;
                }
            }
        }

        //some validation for password
        if($_SESSION['student_data']['password']!=$old_password){
            echo '
                <script>
                    alert("old password incorrect!");
                    window.location.href="../password.html";
                </script>
            ';
            return false;
        }
        else if($new_password!=$confirm_new_password){
            echo '
                <script>
                    alert("confirm_password does not match with new password!.");
                    window.location.href="../password.html";  
                </script>
            ';
            return false;
        }
        else{
            //query with dqtabase
            if(mysqli_query($db_bim,$sql)){
                $_SESSION['student_data']['password']=$new_password;
                echo '
                <script>
                    alert("your password has changed.\n Thank you."); 
                    window.location.href="../password.html";  
                </script>
            ';
            return true;
            }
            else{
                echo"Failed".mysqli_error();
                return false;
            }
        }
       
    }
    else{
        echo '
                <script>
                   window.location.href="../password.html"; 
                </script>
            ';
    }
?>