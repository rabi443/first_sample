<?php
    include_once("connection.php");
    session_start();

    //check if request method is post or not
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $mobile_number = $_POST['number'];
        $user_password = $_POST['password'];
        $role = $_POST['role'];

        if($role=="Student"){

            $sql_bim5= mysqli_query($db_bim,"SELECT * FROM students WHERE mobile_number='$mobile_number' AND password ='$user_password' AND role='$role'");
            
            if(mysqli_num_rows($sql_bim5)>0){
                //fetching the logger data from database
                $student_data= mysqli_fetch_array($sql_bim5);

                $_SESSION['student_data'] = $student_data;
                echo'
                    <script>
                        window.location.href = "dashboard.php";
                    </script>
                ';
            }else{
                echo'
                    <script>
                        alert("Your account doesnot exist! ");
                        window.location.href = "../../index.php";
                    </script>
                '; 
            }
        
        }
    }
    mysqli_close($db_bim);


?>