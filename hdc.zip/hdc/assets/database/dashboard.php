<?php
    include_once("connection.php");
    session_start();
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/body.css">
    <style>
        ul{
            background: #fff;
        }
        li {
            margin-bottom: 15px;
            padding: 10px;
            background: #fff;
            border: none;
        }

        .scrolling-container {
            width: 100%;
            overflow: hidden;
            white-space: nowrap;
            /* border: 1px solid #ccc; */
        }
  
        #scrolling-text {
            display: inline-block;
            padding-left: 100%; /* Initial position: start off-screen */
            animation: scrollText 30s linear infinite; /* Adjust animation duration as needed */
        }
  
        @keyframes scrollText {
            0%{ transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>

<body onload="changeImage()" style="margin:0px;">
    <div id="header" style="width:100%;margin:0px;border-top-left-radius: 5px;">
    <div id="top-section" style="">
        <header>
            <!-- <img src="../../upload_files/hdc.png" alt="HDC" > -->
            <h1>Digital Election Platform</h1> 
        </header>
        
    </div>
    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px; text-align: center; box-sizing: border-box;">
        <nav style="box-sizing: border-box;">
            <a href="dashboard.php" style="color: rgb(172, 166, 214);">Home</a>
            <a href="candidates.php">Candidates</a>
            <a href="result.php">Result</a>
            <a href="inbox.php">Students</a>
            <!-- <a href="about_us.php">About us</a> -->
            <button onclick="window.location.href='session_destroy.php'">Log out </button><br>
        </nav>
    </div> 

    </div>

    <div id="sscrolling-text" style="width:100%;height: 700px; background-color:#fff; text-align:center; margin-left:0%; border:1px; box-sizing: border-box;">
    <img id="dynamic_image" src='../../upload_files/B.png' alt='Photo' style=' width:95%; height:95%; padding-left:3px; margin-bottom:2%; margin-top:1%; box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); box-sizing: border-box;'> 
        
        <?php 
            $sql="SELECT * FROM image";
            $result=mysqli_query($db_bim,$sql);
            if(mysqli_num_rows($result)>0){
                $images = [];
                while($row = mysqli_fetch_assoc($result)) {
                    $image_name=$row["image_name"];
                    $path="../../upload_files/";
                    $main_path=$path.$image_name;
                    $images[]=$main_path;
                    $length=count($images);
                }
            }    
        ?>
        
    </div>

    <div style="text-align:center;">
        <h2 class="title" style="margin-right:25%; margin-left:32%;"><br>Welcome, <?php echo $_SESSION['student_data']['first_name']." ".$_SESSION['student_data']['last_name'];?> </h2>
    </div>

   <div class="container">
        <div class="scrolling-container">
            <span><i id="scrolling-text">'Upcoming Election Name:Class Representator(CR) Election 2024  Starting from july 5, 2024'</i></span>
        </div>
        <ul style="box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <h3 class="title"><u>Current Elections</u></h3>
            <li>
                <button onclick="window.location.href='candidates.php'">Vote Now</button>
                <strong>Election Name:</strong>Class Representator(CR) Election<br>
            </li>
        </ul>

        
        <ul style="box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <h3 class="title"><u>Voting History</u></h3>
            <li>
                <strong>Election Name:</strong> Class Representator(CR) Election 2022<br>
                <strong>Date:</strong> November 8, 2022<br>
            </li>
        </ul>

        <button onclick="window.location.href='user_profile.php'">Profile</button>
        <button onclick="window.location.href='../password.html'">Change Password</button>
        <h3 class="title">Account Settings</h3>
        

        <!-- <button onclick="window.location.href='#'">FAQs</button> -->
        <!-- <button onclick="window.location.href='#'">Contact Support</button>
        <h3 class="title">Help and Support</h3> -->
        
    </div>

    <div>
        <?php
            include_once ("../../header_footer/footer.html");
        ?>
    </div>


                <script>
                    // JavaScript to make navbar fixed when it reaches the top of the page
                    window.onscroll = function() {fixNavbar()};

                    var navbar = document.getElementById("navbar");
                    var sticky = navbar.offsetTop;

                    function fixNavbar() {
                        if (window.pageYOffset >= sticky) {
                            navbar.classList.add("sticky");
                        } else {
                            navbar.classList.remove("sticky");
                        }
                    }

                    //for dynamic image display
                    let images=[
                        <?php
                            foreach($images as $index=>$image_name_url){
                                echo'"'.$image_name_url.'"';
                                if($index<count($images)-1){
                                    echo',';
                                }
                            }
                        ?>
                    ]
                    let current_index=0;
                    function changeImage(){
                        document.getElementById("dynamic_image").src=images[current_index];
                        current_index=(current_index+1)%images.length;
                    }
                    setInterval(changeImage,10000);
                </script>

                <!-- <script>
                    // Array of texts to display
                    const texts = [
                        
                    ];
                    // Index to keep track of the current text
                    let index = 0;

                    // Function to change the text
                    function changeText() {
                        document.getElementById('ssscrolling-text').textContent =texts[index];
                        index = (index + 1) % texts.length; // Move to the next text, loop back to start if necessary
                    }

                    // Initial call to display the first text
                    changeText();

                    // Set interval to change text every 5 seconds (5000 milliseconds)
                    setInterval(changeText, 3000);
                </script>  -->
                        
</body> 
</html>