<?php
    
    session_start();
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }

    include_once("connection.php");
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidates</title>
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/body.css">
    <link rel="stylesheet" href="../../css/dashboard.css">
    
    <style>
        #submit-button{
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }
        ul{
            
            margin-left:10%;
            margin-right:10%;
        }
        
        li{
            background: #fff;
            border-radius:none;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>
<body style="margin:0px;">

    <div id="top-section">
        <header>
        <!-- <img src="../../upload_files/hdc.png" alt="HDC"> -->
            <h1>Digital Election Platform</h1>
            
        </header>
    </div>

    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px;text-align: center; box-sizing: border-box;">
        <nav>  
            <a href="dashboard.php">Home</a>
            <a href="candidates.php" style="color: rgb(172, 166, 214);">Candidates</a>
            <a href="result.php">Result</a>
            <a href="inbox.php">Students</a>
            <!-- <a href="about_us.php">About us</a> -->
            <!-- <button onclick="window.location.href='dashboard.php'" style="float:left;">back</button>  -->
            <button onclick="window.location.href='session_destroy.php'" style="float:right;">Log out</button>
        </nav>
    </div> 
    
    <div id="candidates" style="width:100%; padding:20px; margin-left:0%;">

        <?php

            $user_semester=$_SESSION['student_data']['semester'];
            $user_first_name=$_SESSION['student_data']['first_name'];
            $user_last_name=$_SESSION['student_data']['last_name'];
            $user_mobile_number=$_SESSION['student_data']['mobile_number'];
            $user_roll_no=$_SESSION['student_data']['roll_no'];
            $user_password=$_SESSION['student_data']['password'];

            if($_SERVER['REQUEST_METHOD']=='POST'){
                $first_name=$_POST['first_name'];
                $last_name=$_POST['last_name'];
                $roll_no=$_POST['roll_no'];
                $semester=$_POST['semester'];
                $mobile_number=$_POST['mobile_number'];
                $password=$_POST['password'];

                if($roll_no!=$user_roll_no){
                    echo"
                        <script>
                            alert('Roll_no. Error...');
                            window.location.href='candidates.php';
                        </script>
                    ";
                }else if($password!=$user_password){
                    echo"
                        <script>
                            alert('Password Error...');
                            window.location.href='candidates.php';
                        </script>
                    ";
                }else{

                    //query to check this roll no. is already exist or not in fifth sem candidate form
                    $sql="SELECT * FROM candidates WHERE roll_no='$roll_no' AND semester='$semester'";
                    $result=mysqli_query($db_bim,$sql);

                    if(mysqli_num_rows($result)>0){
                        echo"
                            <script>
                            alert('You have already applied a form for candidate request.')
                            window.location.href='candidates.php';
                            </script>
                        ";
                    }
                    else{
            
                        //query to check this roll no. exist or not in fifth semester of bim 
                        $sql="SELECT * FROM students WHERE roll_no='$roll_no'";
                        $result=mysqli_query($db_bim,$sql);
                        if(mysqli_num_rows($result)>0){
                            //query to insert data in fifth sem candidates table
                            $sql="INSERT INTO candidates (first_name,last_name,roll_no,mobile_number,password,candidate_status,semester) VALUES ('$first_name','$last_name','$roll_no','$mobile_number','$password','pending','$semester')"; 
                            if(!mysqli_query($db_bim,$sql)){
                                echo"
                                <script>
                                alert('Network Error!.')
                                window.location.href='candidates.php';
                                </script>
                                ";
                            }
                            else{
                                echo"
                                <script>
                                alert('Your form has been submitted for candidate request.')
                                window.location.href='candidates.php';
                                </script>
                                ";
                            }
                        }
                        else{
                            echo"
                            <script>
                            alert('You are not student of BIM. SORRY!')
                            window.location.href='candidates.php';
                            </script>
                            ";
                        }
                    }
                }
   
            }

            $sql="SELECT * FROM bim_candidate_form WHERE form='Enable'";
            $result = mysqli_query($db_bim,$sql);
            if(mysqli_num_rows($result)>0){

                while($final_result=mysqli_fetch_assoc($result)){
                    if($final_result['semester']==$user_semester){
                        echo"
                        <div style='background-color:white;width:75%;margin-left:10%;margin-top:20px;padding:20px;'>
                            
                            <button id='close' onclick='toggle_candidates_form()' class='active-button' style='width:100px; padding:5px; box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); display: none; margin-top:20px;'>Close</button>
                            <button id='open' onclick='toggle_candidates_form()' class='active-button' style='width:100px; padding:5px; box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); display: block; margin-top:20px;'>Apply</button>
                            <h3 id='form_text'>Form to apply for candidates is opened.</h3>
        
                            <fieldset id='candidates_form' style='display:none;'>
                                <legend><b>Form for BIM $user_semester semester to apply for candidates.</b></legend>
                                <form method='POST' action='candidates.php'>
                                <input name='first_name' type='hidden' value='$user_first_name' required>
                                <input name='last_name' type='hidden' value='$user_last_name' required>
                                <input name='semester' type='hidden' value='$user_semester' required>
                                Roll no. :<br><input name='roll_no' type='number' placeholder='enter roll_no' required><br>".
                                // Semester :
                                // <select name='semester' required>
                                //     <option value='' ></option>
                                //     <option value='First' >First</option>
                                //     <option value='Second' >Second</option>
                                //     <option value='Third' >Third</option>
                                //     <option value='Fourth' >Fourth</option>
                                //     <option value='Fifth' >Fifth</option>
                                //     <option value='Sixth' >Sixth</option>
                                //     <option value='Seventh' >Seventh</option>
                                //     <option value='Eighth' >Eifhth</option>
                                // </select>
                                "<input name='mobile_number' type='hidden' value='$user_mobile_number' required>
                                Password :<br><input name='password' type='password' required><br><br>
                                <input type='submit' value='Submit'>
                                </form>
                            </fieldset>
                            <hr>
                        </div>
                        ";
                    }else{
                
                    }
                }
            }

        ?>

        <h2 style="margin-left:11%;
            margin-right:10%;"><u>Candidates</u></h2>
        <?php
            // $user_semester=$_SESSION['student_data']['semester'];
            $sql="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='$user_semester'";
            $result = mysqli_query($db_bim, $sql);
            if (mysqli_num_rows($result) > 0) {
                // output data of each row
                while($row = mysqli_fetch_assoc($result)) {

                    $vote=$row["vote"];
                    $roll_no=$row['roll_no'];
                    $profile="";

                    $photo_sql="SELECT profile_photo FROM students WHERE roll_no='$roll_no'";
                    $photo=mysqli_query($db_bim,$photo_sql);
                    
                    if(mysqli_num_rows($photo)>0){
                        $photo_array=mysqli_fetch_array($photo);
                        $profile=$photo_array['profile_photo'];

                    }
                    echo"
                    <ul>
                    <li>
                    <img src='../../upload_files/$profile' alt='profile photo' style='float:right; margin-right:10px; margin-top:0px; width:100px; height:100px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                    <b>First Name</b> : ". $row["first_name"]. "<br><b>Last Name</b> : " . $row["last_name"]. "<br>"."<b>Roll No.</b> : ". $row["roll_no"]."<br>".
                    "<b>Program</b> : BIM <br><br>
                    ";

                    // $student_roll_no=$_SESSION['student_data']['roll_no'];
                    $vote_voted="SELECT status FROM students WHERE roll_no= $user_roll_no";
                    $vote_voted_result=mysqli_query($db_bim,$vote_voted);
                    if($vote_voted_result){
                        if(mysqli_num_rows($vote_voted_result)>0){
                            $vote_status=mysqli_fetch_array($vote_voted_result);
                            if($vote_status['status']==1){
                                echo"
                                <form id='myForm' method=POST action='score_update.php'>
                                    <input type='hidden' value='$vote' name='vote'>
                                    <input type='hidden' value='$roll_no' name='roll_no'>
                                    <input type='submit' value='Voted' id='submit-button'style='background-color:grey;'>
                                </form>
                                </li>
                            </ul>
                            ";
                            }
                            else{
                                echo"
                                <form id='myForm' method=POST action='score_update.php'>
                                    <input type='hidden' value='$vote' name='vote'>
                                    <input type='hidden' value='$roll_no' name='roll_no'>
                                    <input type='submit' onclick='confirm_box()' value='Vote' id='submit-button'>
                                </form>
                                </li>
                            </ul>
                            ";
                            }
                        }
                    }
                }
            }else {
                echo "<div style='background-color:#fff;width:75%;margin-left:10%;margin-top:20px;padding:20px;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'><h3>No any candidates are available for CR Election.</h3></div>";
            }  
        ?> 
        
    </div>

    <div id="footer-section">
        <footer>
            Copyright © 2024, All rights reserved. <a>The Constructor.</a>
        </footer>
    </div>
    <script>

        function toggle_candidates_form() {
            var candidates_form = document.getElementById("candidates_form");
            var openButton = document.getElementById("open");
            var closeButton = document.getElementById("close");
            var text = document.getElementById("form_text");

            if (candidates_form.style.display === "none" || candidates_form.style.display === "") {
                candidates_form.style.display = "block";
                openButton.style.display = "none";
                closeButton.style.display = "block";
                text.style.color = "#fff";
            } else {
                candidates_form.style.display = "none";
                openButton.style.display = "block";
                closeButton.style.display = "none";
                text.style.color = "black";
            }
        }
   

        // Add event listener to the form submit event
        function confirm_box(){
            const form = document.getElementById('myForm');
            // Show confirmation dialog
            if (confirm('You are going to vote this candidate.')) {
                // If user confirms, submit the form programmatically
                form.submit();
            } else {
                // If user cancels, do nothing (or perform other actions)
                console.log('cancelled.');
            }
        };
    </script>

    <script>
    // JavaScript to make navbar fixed when it reaches the top of the page
    window.onscroll = function() {fixNavbar()};

    var navbar = document.getElementById("navbar");
    var sticky = navbar.offsetTop;

    function fixNavbar() {
        if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky");
        } else {
        navbar.classList.remove("sticky");
        }
    }
    </script>

</body>
</html>