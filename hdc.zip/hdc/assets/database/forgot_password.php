<?php
include_once("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot_password</title>
    <link rel="stylesheet" href="../../css/login.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/body.css">
</head>
<body>
    <?php
        // include_once("../../header_footer/header.html");
        echo '
            <div style="text-align:center; margin-top:5px;">
                <img src="../../upload_files/hdc.png" alt="HDC">
                <form name="myform" action="forgot_password1.php" method="POST" style="margin-top:5%; width:22%;border-radius:5px;border:1px solid black; margin-left: 38%; background: #fff;">
                        <br>
                        <h2>Forgot password</h2><br>
                        <input type="number" name="mobile_number" placeholder="Enter mobile number" id="mobile_number" ><br><br>
                        <input type="text" name="roll_no" placeholder="Enter roll_no" id="roll_no"><br><br>
                        <button name="next" style="background-color: rgb(27, 48, 139); border-radius: 2px; width:50%;">next</button><br><br>
                        <a href="../../index.php" style=" text-decoration: none; color: blue; font-size: larger;">cancel</a><br><br><br>
                    
                </form>  
            </div>
        ';
    //    include_once("../../header_footer/footer.html");
    ?>
    
</body>
</html>