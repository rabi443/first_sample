<?php
    $servername="localhost";
    $username="root";
    $password="Rabin";
    $db="hdc";
    // $bim="bim";
    // $bca="bca";
    // $csit="csit";
    // $bhm="bhm";
    // $bbs="bbs";
    // $dashboard="dashboard";
    // $admin="admin";

    // Create connection
    $db_bim= mysqli_connect($servername, $username, $password,$db);
    // $db_bim= mysqli_connect($servername, $username, $password,$bim);
    // $db_bca= mysqli_connect($servername, $username, $password,$bca);
    // $db_csit= mysqli_connect($servername, $username, $password,$csit);
    // $db_bhm= mysqli_connect($servername, $username, $password,$bhm);
    // $db_bbs= mysqli_connect($servername, $username, $password,$bbs);
    // $db_admin= mysqli_connect($servername, $username, $password,$admin);
    // $db_dashboard= mysqli_connect($servername, $username, $password,$dashboard);

    //Check connection
    if (!$db_bim){
    die("Connection failed: " . mysqli_connect_error());
    }
    

?>