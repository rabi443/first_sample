<?php
include_once("../connection.php");

if($_SERVER['REQUEST_METHOD']=='POST'){
    $semester=$_POST['semester'];
}

$status="UPDATE students SET status='0' WHERE semester='$semester'";

$vote="UPDATE candidates SET vote='0' WHERE semester='$semester'";


$student_status=mysqli_query($db_bim,$status);

$candidates_vote=mysqli_query($db_bim,$vote);

if($student_status && $candidates_vote){
    echo"
    <script>
        alert('Reset done of BIM $semester semester.');
        window.location.href='admin_result.php';
    </script>
    
    ";
}
else{
    echo"
    <script>
        alert('error');
        window.location.href='admin_result.php';
    </script>
    
    "; 
}

?>