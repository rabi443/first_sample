<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body style="background-color: aliceblue;overflow:auto;padding:5%;text-align:center;">
        <botton onclick="window.location.href='admin_dashboard.php'" style="float:left;padding:5px;background-color:green;color:white;padding-right:10px;padding-left:10px;">Back</botton><br><br><br><br>
            <?php
           include_once("../connection.php");
            
                $sql="SELECT * FROM image";
                $result=mysqli_query($db_bim,$sql);
                if(mysqli_num_rows($result)>0){
                    while($row = mysqli_fetch_assoc($result)) {
                        $image_name=$row["image_name"];
                        echo"
                            <div style='text-align:center;'>
                                <form method='POST' action='image_delete.php'>
                                <input type='hidden' value='$image_name' name='image_name'>
                                <img src='../../../upload_files/".$row["image_name"]."' alt='image' style='width:300px; height:250px;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>".
                                "<br><button style='margin-left:2%;background-color:brown;color:white;padding-left-right:10px;width:10%;margin-bottom:2%;'>Delete</button></br>
                                </form>  
                            </div>
                        ";


                    }
                }
            
            if($_SERVER['REQUEST_METHOD']=="POST"){
                $image_name=$_POST['image_name'];

                $sql="DELETE FROM image WHERE image_name='$image_name'";
                $result=mysqli_query($db_bim,$sql);
                if($result){
                    echo"
                    <script>
                       // alert('confirm(Are you sure to delete this image?)');
                        window.location.href='image_delete.php';
                        // header('location:dashboard.php');
                    </script>
                    ";
                }

            }
            ?>
        
    </body>
</html>