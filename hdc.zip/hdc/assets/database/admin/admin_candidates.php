<?php
    include_once("../connection.php");
    session_start();
    if(!isset($_SESSION['admin_data'])){
       
        header('location:../../admin.html');
        exit();
    }  
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidates</title>
    <link rel="stylesheet" href="../../../css/dashboard.css">
    <link rel="stylesheet" href="../../../css/footer.css">
    <link rel="stylesheet" href="../../../css/header.css">
    <link rel="stylesheet" href="../../../css/body.css">
    <style>

    </style>
</head>

<body style="margin:0px;">
    <div id="top-section">
        <header>
            <h1>Digital Election Platform</h1>  
        </header>
    </div>

    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px; ">
        <nav>
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="admin_candidates.php"  style="color: rgb(172, 166, 214);">Candidates</a>
            <a href="admin_result.php">Result</a>
            <!-- <a href="admin_inbox.php">Inbox</a>
            <a href="admin_about_us.php">About us</a> -->
            <button onclick="window.location.href='admin_session_destroy.php'">Log out </button><br>
        </nav>
    </div>
    <div class="container" style="background-color:#fff;margin-top:10px;text-align: center;text-align:left;">
    
    <?php
        echo"
        <div style='display:inline;'>
            <p style='display:inline;'><b>Form for BIM students to apply for Candidates:</b></p>
            <form method='POST' action='candidates_form.php' style='display:inline;'>
                <select name='semester' required>

                    <option value=''>select semester</option>
                    <option value='First'>First</option>
                    <option value='Second'>Second</option>
                    <option value='Third'>Third</option>
                    <option value='Fourth'>Fourth</option>
                    <option value='Fifth'>Fifth</option>
                    <option value='Sixth'>Sixth</option>
                    <option value='Seventh'>Seventh</option>
                    <option value='Eighth'>Eighth</option>

                </select>
                <input type='submit' name='disable_enable' id='disable_btn' value='Disable' style='background-color:red;color:white;border-radius:2px;padding:3px; float:right;margin-right:10px;width:60px;'>
                <input type='submit' name='disable_enable' id='enable_btn' value='Enable' style='background-color:green;color:white;border-radius:2px;padding:3px;float:right;margin-right:10px;width:60px;'>
            </form>
        </div>
        ";
    ?>

        <?php
            echo"<div style='margin-top:30px;'>";
                echo"<hr><b>Candidates request of BIM students :</b> <button onclick='BIM_5_open()' id='open_button_for_BIM_5' style='background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>View</button>";
                echo"<button onclick='BIM_5_close()' id='close_button_for_BIM_5' style='display:none;background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>close</button>";
                $results=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="First"');
                if($results){
                    if(mysqli_num_rows($results)>0){
                        
                        echo"<div id='BIM1' style='display:none;'>";
                        echo"<hr><b>First semester:</b>";
                        while($row = mysqli_fetch_assoc($results)) {
                            $first_name=$row["first_name"];
                            $last_name=$row["last_name"];
                            $roll_no=$row["roll_no"];
                            $mobile_number=$row['mobile_number'];
                            $password=$row['password'];
                            $status=$row['candidate_status'];
                            $semester=$row['semester'];
                            echo"
                                <ul>
                                    <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                    "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                    <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                        <input type='hidden' name='first_name' value='$first_name'>
                                        <input type='hidden' name='last_name' value='$last_name'>
                                        <input type='hidden' name='roll_no' value='$roll_no'>
                                        <input type='hidden' name='mobile_number' value='$mobile_number'>
                                        <input type='hidden' name='password' value='$password'>
                                        <input type='hidden' name='semester' value='$semester'>
                                        <input type='radio' name='select' value='approved' required>approve
                                        <input type='radio' name='select' value='rejected' required>reject
                                        <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                    </form>
                                    </li>
                                </ul>
                            ";
                        }   
                        echo"<hr></div>";
                    }
                    else{
                        
                        echo"<div id='BIM1' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>First semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any request from first semester.</p></div>";
                    }
    
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }






                $results2=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Second"');
                if($results2){
                    if(mysqli_num_rows($results2)>0){
                        
                        echo"<div id='BIM2' style='display:none;'>";
                        echo"<hr><b>Second semester:</b>";
                        while($row = mysqli_fetch_assoc($results2)) {
                            $first_name=$row["first_name"];
                            $last_name=$row["last_name"];
                            $roll_no=$row["roll_no"];
                            $mobile_number=$row['mobile_number'];
                            $password=$row['password'];
                            $status=$row['candidate_status'];
                            $semester=$row['semester'];
                            echo"
                                <ul>
                                    <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                    <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                    "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                    <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                        <input type='hidden' name='first_name' value='$first_name'>
                                        <input type='hidden' name='last_name' value='$last_name'>
                                        <input type='hidden' name='roll_no' value='$roll_no'>
                                        <input type='hidden' name='mobile_number' value='$mobile_number'>
                                        <input type='hidden' name='password' value='$password'>
                                        <input type='hidden' name='semester' value='$semester'>
                                        <input type='radio' name='select' value='approved' required>approve
                                        <input type='radio' name='select' value='rejected' required>reject
                                        <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                    </form>
                                    </li>
                                </ul>
                            ";
                        }  
                        echo"<hr></div>";
                    }
                    else{
                        
                        echo"<div id='BIM2' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>second semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any request from second semester.</p></div>";
                    }
    
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }






            $results3=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Third"');
            if($results3){
                if(mysqli_num_rows($results3)>0){
                    
                    echo"<div id='BIM3' style='display:none;'>";
                    echo"<hr><b>Third semester:</b>";
                    while($row = mysqli_fetch_assoc($results3)) {
                        $first_name=$row["first_name"];
                        $last_name=$row["last_name"];
                        $roll_no=$row["roll_no"];
                        $mobile_number=$row['mobile_number'];
                        $password=$row['password'];
                        $status=$row['candidate_status'];
                        $semester=$row['semester'];
                        echo"
                            <ul>
                                <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                    <input type='hidden' name='first_name' value='$first_name'>
                                    <input type='hidden' name='last_name' value='$last_name'>
                                    <input type='hidden' name='roll_no' value='$roll_no'>
                                    <input type='hidden' name='mobile_number' value='$mobile_number'>
                                    <input type='hidden' name='password' value='$password'>
                                    <input type='hidden' name='semester' value='$semester'>
                                    <input type='radio' name='select' value='approved' required>approve
                                    <input type='radio' name='select' value='rejected' required>reject
                                    <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                                </li>
                            </ul>
                        ";
                    }  
                    echo"<hr></div>";
                }
                else{
                    
                    echo"<div id='BIM3' style='display:none;margin-left:20px;'>";
                    echo"<hr><b>Third semester:</b>";
                    echo"<br><p style='margin-left:20px;'>No any request from third semester.</p></div>";
                }

            }
            else{
                die("Error in " . mysqli_connect_error());
            }




            $results4=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Fourth"');
            if($results4){
                if(mysqli_num_rows($results4)>0){
                    
                    echo"<div id='BIM4' style='display:none;'>";
                    echo"<hr><b>Fourth semester:</b>";
                    while($row = mysqli_fetch_assoc($results4)) {
                        $first_name=$row["first_name"];
                        $last_name=$row["last_name"];
                        $roll_no=$row["roll_no"];
                        $mobile_number=$row['mobile_number'];
                        $password=$row['password'];
                        $status=$row['candidate_status'];
                        $semester=$row['semester'];
                        echo"
                            <ul>
                                <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                    <input type='hidden' name='first_name' value='$first_name'>
                                    <input type='hidden' name='last_name' value='$last_name'>
                                    <input type='hidden' name='roll_no' value='$roll_no'>
                                    <input type='hidden' name='mobile_number' value='$mobile_number'>
                                    <input type='hidden' name='password' value='$password'>
                                    <input type='hidden' name='semester' value='$semester'>
                                    <input type='radio' name='select' value='approved' required>approve
                                    <input type='radio' name='select' value='rejected' required>reject
                                    <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                                </li>
                            </ul>
                        ";
                    }   
                    echo"<hr></div>";
                }
                else{
                    
                    echo"<div id='BIM4' style='display:none;margin-left:20px;'>";
                    echo"<hr><b>Fourth semester:</b>";
                    echo"<br><p style='margin-left:20px;'>No any request from fourth semester.</p></div>";
                }

            }
            else{
                die("Error in " . mysqli_connect_error());
            }




            $results5=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Fifth"');
            if($results5){
                if(mysqli_num_rows($results5)>0){
                    
                    echo"<div id='BIM5' style='display:none;'>";
                    echo"<hr><b>Five semester:</b>";
                    while($row = mysqli_fetch_assoc($results5)) {
                        $first_name=$row["first_name"];
                        $last_name=$row["last_name"];
                        $roll_no=$row["roll_no"];
                        $mobile_number=$row['mobile_number'];
                        $password=$row['password'];
                        $status=$row['candidate_status'];
                        $semester=$row['semester'];
                        echo"
                            <ul>
                                <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                    <input type='hidden' name='first_name' value='$first_name'>
                                    <input type='hidden' name='last_name' value='$last_name'>
                                    <input type='hidden' name='roll_no' value='$roll_no'>
                                    <input type='hidden' name='mobile_number' value='$mobile_number'>
                                    <input type='hidden' name='password' value='$password'>
                                    <input type='hidden' name='semester' value='$semester'>
                                    <input type='radio' name='select' value='approved' required>approve
                                    <input type='radio' name='select' value='rejected' required>reject
                                    <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                                </li>
                            </ul>
                        ";
                    }   
                    echo"<hr></div>";
                }
                else{
                    
                    echo"<div id='BIM5' style='display:none;margin-left:20px;'>";
                    echo"<hr><b>Five semester:</b>";
                    echo"<br><p style='margin-left:20px;'>No any request from fifth semester.</p></div>";
                }

            }
            else{
                die("Error in " . mysqli_connect_error());
            }





            $results6=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Sixth"');
            if($results6){
                if(mysqli_num_rows($results6)>0){
                    
                    echo"<div id='BIM6' style='display:none;'>";
                    echo"<hr><b>Six semester:</b>";
                    while($row = mysqli_fetch_assoc($results6)) {
                        $first_name=$row["first_name"];
                        $last_name=$row["last_name"];
                        $roll_no=$row["roll_no"];
                        $mobile_number=$row['mobile_number'];
                        $password=$row['password'];
                        $status=$row['candidate_status'];
                        $semester=$row['semester'];
                        echo"
                            <ul>
                                <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                    <input type='hidden' name='first_name' value='$first_name'>
                                    <input type='hidden' name='last_name' value='$last_name'>
                                    <input type='hidden' name='roll_no' value='$roll_no'>
                                    <input type='hidden' name='mobile_number' value='$mobile_number'>
                                    <input type='hidden' name='password' value='$password'>
                                    <input type='hidden' name='semester' value='$semester'>
                                    <input type='radio' name='select' value='approved' required>approve
                                    <input type='radio' name='select' value='rejected' required>reject
                                    <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                                </li>
                            </ul>
                        ";
                    }  
                    echo"<hr></div>";
                }
                else{
                    
                    echo"<div id='BIM6' style='display:none;margin-left:20px;'>";
                    echo"<hr><b>Six semester:</b>";
                    echo"<br><p style='margin-left:20px;'>No any request from sixth semester.</p></div>";
                }

            }
            else{
                die("Error in " . mysqli_connect_error());
            }





            $results7=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Seventh"');
            if($results7){
                if(mysqli_num_rows($results7)>0){
                    
                    echo"<div id='BIM7' style='display:none;'>";
                    echo"<hr><b>Seven semester:</b>";
                    while($row = mysqli_fetch_assoc($results7)) {
                        $first_name=$row["first_name"];
                        $last_name=$row["last_name"];
                        $roll_no=$row["roll_no"];
                        $mobile_number=$row['mobile_number'];
                        $password=$row['password'];
                        $status=$row['candidate_status'];
                        $semester=$row['semester'];
                        echo"
                            <ul>
                                <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                    <input type='hidden' name='first_name' value='$first_name'>
                                    <input type='hidden' name='last_name' value='$last_name'>
                                    <input type='hidden' name='roll_no' value='$roll_no'>
                                    <input type='hidden' name='mobile_number' value='$mobile_number'>
                                    <input type='hidden' name='password' value='$password'>
                                    <input type='hidden' name='semester' value='$semester'>
                                    <input type='radio' name='select' value='approved' required>approve
                                    <input type='radio' name='select' value='rejected' required>reject
                                    <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                                </li>
                            </ul>
                        ";
                    }   
                    echo"<hr></div>";
                }
                else{
                    
                    echo"<div id='BIM7' style='display:none;margin-left:20px;'>";
                    echo"<hr><b>Seven semester:</b>";
                    echo"<br><p style='margin-left:20px;'>No any request from seventh semester.</p></div>";
                }

            }
            else{
                die("Error in " . mysqli_connect_error());
            }






            $results8=mysqli_query($db_bim,'SELECT * FROM candidates WHERE candidate_status="pending" AND semester="Eighth"');
            if($results8){
                if(mysqli_num_rows($results8)>0){
                    
                    echo"<div id='BIM8' style='display:none;'>";
                    echo"<hr><b>Eight semester:</b>";
                    while($row = mysqli_fetch_assoc($results8)) {
                        $first_name=$row["first_name"];
                        $last_name=$row["last_name"];
                        $roll_no=$row["roll_no"];
                        $mobile_number=$row['mobile_number'];
                        $password=$row['password'];
                        $status=$row['candidate_status'];
                        $semester=$row['semester'];
                        echo"
                            <ul>
                                <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                <b>Name</b> : ". $row["first_name"]." ". $row["last_name"]. " , "."<b>Roll_no</b> : ". $row["roll_no"]." , ".
                                "<b>Semester</b> : ".$row["semester"]." , <b>Status</b> : ".$row["candidate_status"]."
                                <form id='approve_reject' method='POST' action='admin_inbox1.php'>
                                    <input type='hidden' name='first_name' value='$first_name'>
                                    <input type='hidden' name='last_name' value='$last_name'>
                                    <input type='hidden' name='roll_no' value='$roll_no'>
                                    <input type='hidden' name='mobile_number' value='$mobile_number'>
                                    <input type='hidden' name='password' value='$password'>
                                    <input type='hidden' name='semester' value='$semester'>
                                    <input type='radio' name='select' value='approved' required>approve
                                    <input type='radio' name='select' value='rejected' required>reject
                                    <input id='approve_button' onclick='approve()' type='submit' value='submit'style=' background-color:green;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                                </li>
                            </ul>
                        ";
                    }   
                    echo"<hr></div>";
                }
                else{
                    
                    echo"<div id='BIM8' style='display:none;margin-left:20px;'>";
                    echo"<hr><b>Eight semester:</b>";
                    echo"<br><p style='margin-left:20px;'>No any request from eight semester.</p></div>";
                }

            }
            else{
                die("Error in " . mysqli_connect_error());
            }

        echo"</div>";
        ?>




        <?php

        echo"<div style=''>";
            

            echo"<br><br><hr><b>Approved candidates list of BIM:</b> <button onclick='candidate_open()' id='open_candidate' style='background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>View</button>";
            echo"<button onclick='candidate_close()' id='close_candidate' style='display:none;background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>close</button>";
                //FIRST
                $candidates_sql1="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='First'";
                $candidates_result1=mysqli_query($db_bim,$candidates_sql1);

                if($candidates_result1){

                    if(mysqli_num_rows($candidates_result1)>0){
                        echo"<div id='candidates1' style='display:none;'>";
                        echo"<hr><b>First semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result1)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates1' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>First semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from first semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }

                //SECOND

                $candidates_sql2="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Second'";
                $candidates_result2=mysqli_query($db_bim,$candidates_sql2);

                if($candidates_result2){

                    if(mysqli_num_rows($candidates_result2)>0){
                        echo"<div id='candidates2' style='display:none;'>";
                        echo"<hr><b>Secondt semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result2)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates2' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Second semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from second semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }

                //THIRD

                $candidates_sql3="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Third'";
                $candidates_result3=mysqli_query($db_bim,$candidates_sql3);

                if($candidates_result3){

                    if(mysqli_num_rows($candidates_result3)>0){
                        echo"<div id='candidates3' style='display:none;'>";
                        echo"<hr><b>Third semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result3)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates3' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Third semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from third semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }

                //FOURTH

                $candidates_sql4="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Fourth'";
                $candidates_result4=mysqli_query($db_bim,$candidates_sql4);

                if($candidates_result4){

                    if(mysqli_num_rows($candidates_result4)>0){
                        echo"<div id='candidates4' style='display:none;'>";
                        echo"<hr><b>Fourth semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result4)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates4' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Fourth semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from fourth semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }

                //FIFTH

                $candidates_sql5="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Fifth'";
                $candidates_result5=mysqli_query($db_bim,$candidates_sql5);

                if($candidates_result5){

                    if(mysqli_num_rows($candidates_result5)>0){
                        echo"<div id='candidates5' style='display:none;'>";
                        echo"<hr><b>Fifth semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result5)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                        echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates5' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Fifth semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from fifth semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }

                //SIXTH

                $candidates_sql6="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Sixth'";
                $candidates_result6=mysqli_query($db_bim,$candidates_sql6);

                if($candidates_result6){

                    if(mysqli_num_rows($candidates_result6)>0){
                        echo"<div id='candidates6' style='display:none;'>";
                        echo"<hr><b>Sixth semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result6)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates6' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Sixth semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from sixth semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }


                //SEVENTH

                $candidates_sql7="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Seventh'";
                $candidates_result7=mysqli_query($db_bim,$candidates_sql7);

                if($candidates_result7){

                    if(mysqli_num_rows($candidates_result7)>0){
                        echo"<div id='candidates7' style='display:none;'>";
                        echo"<hr><b>Seventh semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result7)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates7' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Seven semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from seventh semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }


                //EIGHTH
                $candidates_sql8="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='Eighth'";
                $candidates_result8=mysqli_query($db_bim,$candidates_sql8);

                if($candidates_result8){

                    if(mysqli_num_rows($candidates_result8)>0){
                        echo"<div id='candidates8' style='display:none;'>";
                        echo"<hr><b>Eight semester:</b>";
                        while($candidates=mysqli_fetch_assoc($candidates_result8)){
                            echo"
                                <p style='color:green;'><b>Name</b> : ". $candidates["first_name"]." ". $candidates["last_name"]. " "." , <b>Roll_no</b> : ". $candidates["roll_no"]." "." ,
                                <b>Mobile_number</b> : ".$candidates["mobile_number"]."</p>
                                <form id='remove_candidates' method='POST' action='delete_candidates.php'>
                                    <input type='hidden' name='roll_no' value='".$candidates["roll_no"]."' style=''><br>
                                    <input id='remove_button' onclick='remove_candidates()' type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                                </form>
                            ";
                        }
                    echo"<hr></div>";
                    }
                    else{
                        echo"<div id='candidates8' style='display:none;margin-left:20px;'>";
                        echo"<hr><b>Eight semester:</b>";
                        echo"<br><p style='margin-left:20px;'>No any candidates available from eighth semester.</p></div>";
                    }
                }
                else{
                    die("Error in " . mysqli_connect_error());
                }

        echo"</div>";
        ?>


<?php
            $candidates_request="SELECT * FROM candidates WHERE candidate_status='rejected'";
            $candidates_request_result=mysqli_query($db_bim,$candidates_request);

            if($candidates_request_result){

                if(mysqli_num_rows($candidates_request_result)>0){

                    echo"<br><br><hr><b>Rejected candidates list of BIM :</b> <button onclick='requested_candidate_open()' id='open_candidate_request' style='background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>View</button>";
                    echo"<button onclick='requested_candidate_close()' id='close_candidate_request' style='display:none;background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>close</button>";
                
                    echo"<div id='requested_candidates' style='display:none;'>";
                    while($requested_candidate=mysqli_fetch_assoc($candidates_request_result)){
                        echo"
                        <ul style='color:green;'>
                            <li style='box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                            <b>Name</b> : ". $requested_candidate["first_name"]." " . $requested_candidate["last_name"]. " "." , <b>Roll_no</b> : ". $requested_candidate["roll_no"]." "." ,
                            <b>Semesterr</b> : ".$requested_candidate["semester"]."
                            <form id='remove_candidates' method='POST' action='delete_rejected_candidates.php'>
                                <input type='hidden' name='roll_no' value='".$requested_candidate["roll_no"]."' style=''><br>
                                <input type='submit' value='remove'style='background-color:red;color:white;border-radius:3px;padding:1px;width:60px;'>
                            </form>
                            </li>
                        </ul>
                        ";
                    }
                    echo"<hr></div>";
                }
                else{
                    echo"<br><br><hr><b>Rejected candidates list of BIM:</b> <button onclick='requested_candidate_open()' id='open_candidate_request' style='background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>View</button>";
                    echo"<button onclick='requested_candidate_close()' id='close_candidate_request' style='display:none;background-color:green;color:white;border-radius:3px;padding:4px;width:60px;float:right;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border:1px solid black;'>close</button>";
                    echo"<div id='requested_candidates' style='display:none;margin-left:20px;'>";
                    echo"<br>No any candidates are rejected.</div>";

                }
            }
            else{
                die("Error in " . mysqli_connect_error());
            }


        ?>


        
    </div>
    <div>
        <?php
            include_once ("../../../header_footer/footer.html");
        ?>
    </div>

    <script>

        //CANDIDATES REQUEST APPROVE OR REJECT
        function BIM_5_open(){
            document.getElementById('BIM1').style.display="block";
            document.getElementById('BIM2').style.display="block";
            document.getElementById('BIM3').style.display="block";
            document.getElementById('BIM4').style.display="block";
            document.getElementById('BIM5').style.display="block";
            document.getElementById('BIM6').style.display="block";
            document.getElementById('BIM7').style.display="block";
            document.getElementById('BIM8').style.display="block";
            document.getElementById('open_button_for_BIM_5').style.display="none";
            document.getElementById('close_button_for_BIM_5').style.display="block";  
            
            document.getElementById('candidates1').style.display="none";
            document.getElementById('candidates2').style.display="none";
            document.getElementById('candidates3').style.display="none";
            document.getElementById('candidates4').style.display="none";
            document.getElementById('candidates5').style.display="none";
            document.getElementById('candidates6').style.display="none";
            document.getElementById('candidates7').style.display="none";
            document.getElementById('candidates8').style.display="none";
            document.getElementById('close_candidate').style.display="none";
            document.getElementById('open_candidate').style.display="block";
           
        }

        function BIM_5_close(){
            document.getElementById('BIM1').style.display="none";
            document.getElementById('BIM2').style.display="none";
            document.getElementById('BIM3').style.display="none";
            document.getElementById('BIM4').style.display="none";
            document.getElementById('BIM5').style.display="none";
            document.getElementById('BIM6').style.display="none";
            document.getElementById('BIM7').style.display="none";
            document.getElementById('BIM8').style.display="none";
            document.getElementById('close_button_for_BIM_5').style.display="none";
            document.getElementById('open_button_for_BIM_5').style.display="block";
        }

        function approve(){
            // document.getElementById('approve_reject').action="admin_inbox1.php";
            return true;

        }

        // function reject(){
        //     //document.getElementById('reject_button').value="rejected";
        //     return true;
        // }

        //REMOVE CANDIDATES
        function candidate_open(){
            document.getElementById('candidates1').style.display="block";
            document.getElementById('candidates2').style.display="block";
            document.getElementById('candidates3').style.display="block";
            document.getElementById('candidates4').style.display="block";
            document.getElementById('candidates5').style.display="block";
            document.getElementById('candidates6').style.display="block";
            document.getElementById('candidates7').style.display="block";
            document.getElementById('candidates8').style.display="block";
            document.getElementById('open_candidate').style.display="none";
            document.getElementById('close_candidate').style.display="block"; 
            
            
            document.getElementById('BIM1').style.display="none";
            document.getElementById('BIM2').style.display="none";
            document.getElementById('BIM3').style.display="none";
            document.getElementById('BIM4').style.display="none";
            document.getElementById('BIM5').style.display="none";
            document.getElementById('BIM6').style.display="none";
            document.getElementById('BIM7').style.display="none";
            document.getElementById('BIM8').style.display="none";
            document.getElementById('close_button_for_BIM_5').style.display="none";
            document.getElementById('open_button_for_BIM_5').style.display="block";
            
        }

        function candidate_close(){
            document.getElementById('candidates1').style.display="none";
            document.getElementById('candidates2').style.display="none";
            document.getElementById('candidates3').style.display="none";
            document.getElementById('candidates4').style.display="none";
            document.getElementById('candidates5').style.display="none";
            document.getElementById('candidates6').style.display="none";
            document.getElementById('candidates7').style.display="none";
            document.getElementById('candidates8').style.display="none";
            document.getElementById('close_candidate').style.display="none";
            document.getElementById('open_candidate').style.display="block";
        }
        function remove_candidates(){
            if(confirm("You are going to remove this candidate.")){
                document.getElementById('remove_candidates').action="delete_candidates.php";
                return true;
            }
            else{
                return false;
            }
        }

        /////

        function requested_candidate_open(){
            document.getElementById('requested_candidates').style.display="block";
            document.getElementById('open_candidate_request').style.display="none";
            document.getElementById('close_candidate_request').style.display="block";   
        }

        function requested_candidate_close(){
            document.getElementById('requested_candidates').style.display="none";
            document.getElementById('close_candidate_request').style.display="none";
            document.getElementById('open_candidate_request').style.display="block";
        }


    </script>
</body>
</html>
