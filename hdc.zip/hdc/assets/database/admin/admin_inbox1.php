<?php
   include_once("../connection.php");

    if($_SERVER['REQUEST_METHOD']=='POST'){
        $first_name=$_POST['first_name'];
        $last_name=$_POST['last_name'];
        $roll_no=$_POST['roll_no'];
        $mobile_number=$_POST['mobile_number'];
        $password=$_POST['password'];
        $approve_reject=$_POST['select'];
        $semester=$_POST['semester'];
        // echo"$approve_reject";
       
        if($approve_reject=="approved"){
            $sql="SELECT * FROM candidates WHERE roll_no='$roll_no' AND candidate_status='approved' AND semester='$semester'";
            $result=mysqli_query($db_bim,$sql);

            $sql1="SELECT * FROM candidates WHERE semester='$semester' AND candidate_status='approved'";
            $result1=mysqli_query($db_bim,$sql1);

            if($result){
                if(mysqli_num_rows($result)>0){
                    echo"
                    <script>
                    alert('This candidate has been already approved.')
                    window.location.href='admin_candidates.php';
                    </script>
                ";
                }
                else if(mysqli_num_rows($result1)==2){
                    echo"
                    <script>
                    alert('Two candidates are already approved.')
                    window.location.href='admin_candidates.php';
                    </script>
                ";  
                }
                else{
                    $sql="UPDATE candidates SET candidate_status='$approve_reject' WHERE roll_no='$roll_no' AND semester='$semester'";
                    $result=mysqli_query($db_bim,$sql);
    
                    if($result){
                        echo"
                        <script>
                            alert('Approved.');
                            window.location.href='admin_candidates.php';
                        </script>
                        ";
                    }
                }
            }
        }
        else if($approve_reject=='rejected'){

            $sql="SELECT candidate_status FROM candidates WHERE roll_no='$roll_no' AND semester='$semester'";
            $result=mysqli_query($db_bim,$sql);
            if($result){
                if(mysqli_num_rows($result)>0){
                    $row=mysqli_fetch_array($result);
                    if($row['candidate_status']=='approved'){
                        echo"
                        <script>
                            alert('This candidate has already ".$row['candidate_status'] ." So can not be reject now.');
                            window.location.href='admin_candidates.php';
                        </script>
                        "; 
                    }
                    else if($row['candidate_status']=='rejected'){
                        echo"
                        <script>
                            alert('Rejected');
                            window.location.href='admin_candidates.php';
                        </script>
                        "; 
                    }
                    else{
                        $sql="UPDATE candidates SET candidate_status='$approve_reject' WHERE roll_no='$roll_no' AND semester='$semester'";
                   
                        $result=mysqli_query($db_bim,$sql);
                        if($result){
                            echo"
                            <script>
                                alert('$approve_reject');
                                window.location.href='admin_candidates.php';
                            </script>
                            "; 
                        }
                    }
                }
            }
        }
        else{
            $sql="SELECT candidate_status FROM candidates WHERE roll_no='$roll_no' AND semester='$semester'";
            $result=mysqli_query($db_bim,$sql);
            if($result){
                if(mysqli_num_rows($result)>0){
                    $row=mysqli_fetch_array($result);
                    if($row['candidate_status']=='approved'){
                        echo"
                        <script>
                            alert('Approved');
                            window.location.href='admin_candidates.php';
                        </script>
                        "; 
                    }
                    else if($row['candidate_status']=='rejected'){
                        echo"
                        <script>
                            alert('Rejected');
                            window.location.href='admin_candidates.php';
                        </script>
                        "; 
                    }
                    else{
                        echo"
                        <script>
                            alert('Pending');
                            window.location.href='admin_candidates.php';
                        </script>
                        "; 
                    }
                }
            }
           
        }

       


    }
    ?>