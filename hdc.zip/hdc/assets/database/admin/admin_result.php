<?php
    session_start();
    if(!isset($_SESSION['admin_data'])){
       
        header('location:../../admin.html');

    }

    include_once("../connection.php");


    if($_SERVER['REQUEST_METHOD']=='POST'){
        $result_status=$_POST['result_status'];
        $semester=$_POST['semester'];

        $update_sql="UPDATE result SET results='$result_status' WHERE semester='$semester'";
        if(mysqli_query($db_bim,$update_sql)){

            if($result_status=='published'){
                echo"
                <script>
                alert('Result published');
                window.location.href='admin_result.php';
                </script>
                ";
            }
            else{
                echo"
                <script>
                alert('Result hided');
                window.location.href='admin_result.php';
                </script>
                ";
            }
           
        }
    }
?>  
     
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results</title>
    <link rel="stylesheet" href="../../../css/dashboard.css">
    <link rel="stylesheet" href="../../../css/footer.css">
    <link rel="stylesheet" href="../../../css/header.css">
    <link rel="stylesheet" href="../../../css/body.css">
    <style>
        ul{
            background: #fff;
        }
        li {
            margin-bottom: 15px;
            padding: 10px;
            background: #fff;
            border: none;
        }
        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>

<body style="margin:0px;">
    <div id="top-section">
        <header>
            <h1>Digital Election Platform</h1>  
        </header>
    </div>
    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px;text-align: center; ">
        <nav>
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="admin_candidates.php">Candidates</a>
            <a href="admin_result.php"   style="color: rgb(172, 166, 214);">Result</a>
            <!-- <a href="admin_inbox.php">Inbox</a>
            <a href="admin_about_us.php">About us</a> -->
            <button onclick="window.location.href='admin_session_destroy.php'">Log out </button><br>
        </nav>
    </div> 

    
    <div style=" width:85%; margin-left:7.5%;">


        <div class="container" style="background-color:#fff;margin-top:10px;text-align: center;text-align:left;">
    
            <?php
                    echo"
                    <div style='display:inline;'>
                        <p style='display:inline;'><b>Publish the CR election result of :</b></p>
                        <form method='POST' action='admin_result.php' style='display:inline;'>
                            <select name='semester' required style='margin-top:10px;'>
    
                                <option value=''>select semester</option>
                                <option value='First'>First</option>
                                <option value='Second'>Second</option>
                                <option value='Third'>Third</option>
                                <option value='Fourth'>Fourth</option>
                                <option value='Fifth'>Fifth</option>
                                <option value='Sixth'>Sixth</option>
                                <option value='Seventh'>Seventh</option>
                                <option value='Eighth'>Eighth</option>
    
                            </select>
                          
                            <button value='not-published' name='result_status' style='border-radius:5px; background-color:red;width:100px; float:left; margin-left:20px; padding:8px; float:right;margin-top:0px;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border-radius:3px solid black;'>Hide</button>
                            <button value='published' name='result_status' style='border-radius:5px; width:100px; float:left; margin-left:20px; padding:8px; float:right;margin-top:0px;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border-radius:3px solid black;'>Publish</button>
                        </form>
                    </div>
                    ";
            ?>
         </div>

         <div class="container" style="background-color:#fff;margin-top:10px;text-align: center;text-align:left;">
            <?php

                echo"
                <div style='display:inline;'>
                    <p style='display:inline;'><b>Click the button to reset all votes and student vote_status of BIM:</b></p>
                    <form method='POST' action='reset_vote_status.php' style='display:inline;'>
                        <select name='semester' required style='margin-top:10px;'>

                            <option value=''>select semester</option>
                            <option value='First'>First</option>
                            <option value='Second'>Second</option>
                            <option value='Third'>Third</option>
                            <option value='Fourth'>Fourth</option>
                            <option value='Fifth'>Fifth</option>
                            <option value='Sixth'>Sixth</option>
                            <option value='Seventh'>Seventh</option>
                            <option value='Eighth'>Eighth</option>

                        </select>
                    <button value='reset' name='reset' style='border-radius:5px; width:100px; float:left; margin-left:20px; padding:8px; float:right;margin-top:0px;box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);border-radius:3px solid black;background-color:green; color:#fff;'>Reset</botton>
                    </form>
                </div>
                ";
            ?>

        </div>

          
    </div>


    <div>

    </div>

    <div class="container">
        
    </div>

    <div>
        <?php
            include_once ("../../../header_footer/footer.html");
        ?>
    </div>
    
    <script>

        // function confirm_show(){
        //     if (confirm('You are going to publish  result.')) {
        //         return true;
        //         // If user confirms, submit the form programmatically
        //         // form.submit();
        //     } else {
        //         // If user cancels, do nothing (or perform other actions)
        //         // console.log('cancelled.');
        //         return false;
        //     }
        // };

        // function confirm_hide(){
        //     if (confirm('You are going to hide result.')) {
        //         return true;
        //         // If user confirms, submit the form programmatically
        //         // form.submit();
        //     } else {
        //         // If user cancels, do nothing (or perform other actions)
        //         // console.log('cancelled.');
        //         return false;
        //     }
        // };
    </script>
    
</body>
</html>