<?php
include_once("../connection.php");

if($_SERVER['REQUEST_METHOD']=='POST'){
    $roll_no=$_POST['roll_no'];

    
    $sql1="UPDATE candidates SET candidate_status='pending' WHERE roll_no='$roll_no'";

  
    $result1=mysqli_query($db_bim,$sql1);
   

    if($result1){
        echo"
            <script>
                alert('Removed.');
                window.location.href='admin_candidates.php';
            </script>
        ";
    }
    else{
        die("Network error".mysqli_connect_error());
        echo"
            <script>
                window.location.href='admin_candidates.php';
            </script>
        ";

    }
}


?>