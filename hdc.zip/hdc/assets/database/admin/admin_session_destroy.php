<?php
    include_once("../connection.php");
    session_start();
    if(isset($_SESSION['admin_data'])){
       

        unset($_SESSION['admin_data']);
        // // remove all session variables
        // session_unset();

        // // destroy the session
        // session_destroy();

        header('location:admin_dashboard.php');

    }
?>