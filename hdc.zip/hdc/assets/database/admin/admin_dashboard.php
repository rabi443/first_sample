<?php
    include_once("../connection.php");
    session_start();
    if (!isset($_SESSION['admin_data'])) {
        header('location:../../admin.html');
        exit(); // Ensure the script stops executing after the redirect
    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../../../css/dashboard.css">
    <link rel="stylesheet" href="../../../css/footer.css">
    <link rel="stylesheet" href="../../../css/header.css">
    <link rel="stylesheet" href="../../../css/body.css">
    <style>
        ul {
            background: #fff;
            list-style-type: none; /* Ensure list items don't have bullets */
            padding: 0;
        }
        li {
            margin-bottom: 15px;
            padding: 10px;
            background: #fff;
            border: none;
        }
        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
        .active-button {
            background-color: green;
            color: #fff;
            width: 100px;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
        .active-button:hover {
            background-color: darkgreen;
        }
        .button {
            background-color: rgb(94, 75, 115);
            color: white;
            border: none;
            padding: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body style="margin:0;">
    <div id="top-section">
        <header>
            <h1>Digital Election Platform</h1>  
        </header>
    </div>
    <div id="navbar" style="background-color: rgb(94, 75, 115); padding: 15px; text-align: center; box-sizing: border-box;">
        <nav>
            <a href="admin_dashboard.php" style="color: rgb(172, 166, 214);">Dashboard</a>
            <a href="admin_candidates.php">Candidates</a>
            <a href="admin_result.php">Result</a>
            <!-- <a href="admin_inbox.php">Inbox</a>
            <a href="admin_about_us.php">About us</a> -->
            <button  onclick="window.location.href='admin_session_destroy.php'">Log out</button>
        </nav>
    </div> 

    <div style="text-align:center;">
        <h2 class="title" style="margin: 20px auto; width: fit-content;">
            Hello, <?php echo htmlspecialchars($_SESSION['admin_data']['first_name']." ".$_SESSION['admin_data']['last_name']); ?> <br>
            Welcome to Himalaya Darshan College
        </h2> 
    </div>

    <div class="container">
        <ul style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <li>
                <form action="image.php" method="post" enctype="multipart/form-data">
                    <h3><u>Image for Dashboard</u></h3>
                    <label for="image">Choose image:</label>
                    <input type="file" name="image" id="image" style="width: 25%; margin-bottom: 20px;" required>
                    <button class="active-button" type="submit">Upload</button>
                    <hr>
                </form>
                <p>To delete image from dashboard: <button class="active-button" onclick="window.location.href='image_delete.php'">View here</button></p>
            </li>
        </ul>

        <ul style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <li>
                <?php
                    $students = "SELECT * FROM students";
                    $result = mysqli_query($db_bim, $students);

                    if ($result) {
                        if (mysqli_num_rows($result) > 0) {
                            echo "<button id='close' onclick='toggleStudentList()' class='active-button' style='display: none;'>Close</button>";
                            echo "<button id='open' onclick='toggleStudentList()' class='active-button' style='display: block;'>View</button>";

                            echo "<u><h3>Total no. of students in BIM :</h3></u>";
                            $i = 1;

                            echo "<div id='students' style='display:none;'>";
                            while ($students_array = mysqli_fetch_assoc($result)) {
                                echo "<div>
                                        <ul>
                                            <li style='box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                                <form method='POST' action='delete_students.php'>
                                                    <input type='hidden' value='" . htmlspecialchars($students_array['roll_no']) . "' name='roll_no'>
                                                    <input type='hidden' value='" . htmlspecialchars($students_array['semester']) . "' name='semester'>
                                                    <input type='hidden' onclick='return true_false()' value='Delete account' style='float: right; background-color: red; color: #fff;'>
                                                </form>
                                                ($i) <b>" . htmlspecialchars($students_array['first_name']) . " " . htmlspecialchars($students_array['middle_name']) . " " . htmlspecialchars($students_array['last_name']) . " , roll_no: " . htmlspecialchars($students_array['roll_no']) . " , 
                                                contact_no: " . htmlspecialchars($students_array['mobile_number']) . ", semester : ".htmlspecialchars($students_array['semester'])."</b>
                                            </li>
                                        </ul>
                                    </div>";
                                $i++;
                            }
                            echo "</div>";
                        }
                    }
                ?> 
            </li>
        </ul>

        <ul style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
            <li>
                <!-- Additional content can go here -->
            </li>
        </ul>
    </div>
    
    <?php include_once("../../../header_footer/footer.html"); ?>

    <script>
        function true_false(){
            if(confirm("You are going to delete this students account.")){
                return true;
            }
            else{
                return false;
            }
        }
        function toggleStudentList() {
            var studentsDiv = document.getElementById("students");
            var openButton = document.getElementById("open");
            var closeButton = document.getElementById("close");

            if (studentsDiv.style.display === "none" || studentsDiv.style.display === "") {
                studentsDiv.style.display = "block";
                openButton.style.display = "none";
                closeButton.style.display = "block";
            } else {
                studentsDiv.style.display = "none";
                openButton.style.display = "block";
                closeButton.style.display = "none";
            }
        }

        // JavaScript to make navbar fixed when it reaches the top of the page
        window.onscroll = function() { fixNavbar(); };

        var navbar = document.getElementById("navbar");
        var sticky = navbar.offsetTop;

        function fixNavbar() {
            if (window.pageYOffset >= sticky) {
                navbar.classList.add("sticky");
            } else {
                navbar.classList.remove("sticky");
            }
        }
    </script>
</body>
</html>
