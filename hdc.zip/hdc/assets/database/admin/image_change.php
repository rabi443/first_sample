<?php
           include_once("../connection.php");
            
            $sql="SELECT * FROM image";
            $result=mysqli_query($db_dashboard,$sql);
            if(mysqli_num_rows($result)>0){
                $images = [];
                while($row = mysqli_fetch_assoc($result)) {
                    $image_name=$row["image_name"];
                    $path="../../upload_files/";
                    $main_path=$path.$image_name;
                    $images[]=$main_path;
                    $length=count($images);
                }
                for($i=0;$i<$length;$i++){
                    echo $images[$i];
                
                }
                
            }
            else{
                echo"
                    <script>
                        alert('No images.');
                    </script>
                ";
            }
            
        ?>