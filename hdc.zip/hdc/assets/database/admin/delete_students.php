<?php
include_once("../connection.php");
if($_SERVER['REQUEST_METHOD']=='POST'){
    $roll_no=$_POST['roll_no'];
    $semester=$_POST['semester'];

    $sql1="DELETE FROM students WHERE roll_no='$roll_no' AND semester='$semester'";
   
    $sql3="DELETE FROM candidates WHERE roll_no='$roll_no' AND semester='$semester'";


    $result1=mysqli_query($db_bim,$sql1);
  
    $result3=mysqli_query($db_bim,$sql3);

    if($result1 && $result3){
        echo"
            <script>
                alert('Deleted');
                window.location.href='admin_dashboard.php';
            </script>
        ";
    }
    else{
        die("Network error".mysqli_connect_error());
        echo"
            <script>
                window.location.href='admin_dashboard.php';
            </script>
        ";

    }
}

?>