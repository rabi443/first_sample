<?php
    include_once("../connection.php");

    if($_SERVER['REQUEST_METHOD']=='POST'){
        $value=$_POST['disable_enable'];
        $semester=$_POST['semester'];
        
        $sql="UPDATE bim_candidate_form SET form='$value' where semester='$semester'";
        $result=mysqli_query($db_bim,$sql);
        if($result){
           echo"
                <script>
                    alert('You have ".$value." Form for BIM $semester semester to apply for Candidates.');
                    window.location.href='admin_candidates.php';
                </script>
               
            ";
        }
        else{
            echo"
            <script>
                alert('error.');
                window.location.href='admin_candidates.php';
            </script>
           
        ";
        }
    }


    ?>