<?php
    include_once("../connection.php");
    session_start();
    if(!isset($_SESSION['admin_data'])){
       
        header('location:../../admin.html');

    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../../css/dashboard.css">
    <link rel="stylesheet" href="../../../css/footer.css">
    <link rel="stylesheet" href="../../../css/header.css">
    <link rel="stylesheet" href="../../../css/body.css">
    <style>
        ul{
            background: #fff;
        }
        li {
            margin-bottom: 15px;
            padding: 10px;
            background: #fff;
            border: none;
        }
        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>

<body style="margin:0px;">
    <div id="top-section">
        <header>
            <h1>Digital Election Platform</h1>  
        </header>
    </div>
    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px;text-align: center; ">
        <nav>
            <a href="admin_dashboard.php">Dashboard</a>
            <a href="admin_candidates.php">Candidates</a>
            <a href="admin_result.php">Result</a>
            <!-- <a href="admin_inbox.php"  style="color: rgb(172, 166, 214);">Inbox</a>
            <a href="admin_about_us.php">About us</a> -->
            <button onclick="window.location.href='admin_session_destroy.php'">Log out </button><br>
        </nav>
    </div> 

    
    <div style="text-align:center;">
        </div>

        <div>

    </div>

    <div class="container">
        
    </div>

    <div>
        <?php
            include_once ("../../../header_footer/footer.html");
        ?>
    </div>
    
    
</body>
</html>