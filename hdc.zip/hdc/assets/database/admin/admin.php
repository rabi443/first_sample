<?php
    session_start();
    include_once("../connection.php");

    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        $mobile_number=$_POST['number'];
        $password=$_POST['password'];

        $check_query = "SELECT * FROM admin WHERE mobile_number = '$mobile_number' AND password ='$password'";
        $admin = mysqli_query($db_bim, $check_query);
        
        if(mysqli_num_rows($admin)>0){
            
            //fetching the admin data from database
            $admin_data = mysqli_fetch_array($admin);

            //setting the admin  data in session
            $_SESSION['admin_data'] = $admin_data;
            
            //redirecting to admin_dashboard
            echo'
                <script>
                    window.location.href = "admin_dashboard.php";
                </script>
            ';
        }
        else {
            echo '
                <script>
                    alert("Invalid number and password!\n Sorry----!\n or you have not authority to access admin dashboard!!!.");
                    window.location.href = "../../admin.html";
                </script>
                exit();
            ';
        }

    }
   mysqli_close($db_bim);


?>

