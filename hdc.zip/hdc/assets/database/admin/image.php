<?php
    include_once("../connection.php");
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if (isset($_FILES['image'])){
            $image = $_FILES['image']['name'];

            
                $sql="SELECT * FROM image WHERE image_name='$image'";
                if(mysqli_num_rows(mysqli_query($db_bim,$sql))>0){
                    echo"
                    <script>
                        alert('SORRY!..image with this name already exist.');
                        window.location.href='admin_dashboard.php';
                        // header('location:dashboard.php');
                    </script>
                    ";
                }
                // Upload the image 
                $target_dir = "../../../upload_files/";
                $target_file= $target_dir . basename($_FILES["image"]["name"]);
                if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    die("Error uploading profile photo.");
                }
                $sql="INSERT INTO image (image_name) VALUES ('$image')";
    
                if(!mysqli_query($db_bim,$sql)){
                    echo "Error: " . $sql ."<br>" . mysqli_error($db_dashboard);
                }
                else{
                    echo"
                        <script>
                            alert('Successfully uploaded your image.');
                            window.location.href='admin_dashboard.php';
                            // header('location:dashboard.php');
                        </script>
                        ";
                }
    
            
        }
        else{
            die("File uploads are missing.");
        }


    }

?>