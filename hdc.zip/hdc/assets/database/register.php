<?php
include_once("connection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if files are uploaded
    if (isset($_FILES['image'])) {
        $first_name = $_POST['first_name'];
        $middle_name = $_POST['middle_name'];
        $last_name = $_POST['last_name'];
        $mobile_number = $_POST['number'];
        //$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $user_password = $_POST['password'];
        $gmail = $_POST['gmail'];
        $address = $_POST['address'];
        // $age = $_POST['age'];
        $program = $_POST['program'];
        $semester = $_POST['semester'];
        $dob = $_POST['dob'];
        $profile_photo = $_FILES['image']['name'];
        $roll_no = $_POST['roll_no'];
        $gender = $_POST['gender'];
        // $role = $_POST['role'];
        $status = $_POST['status'];
        // $score = $_POST['score'];
        $batch = $_POST['batch'];
        // echo "$first_name", "$middle_name", "$last_name", "$mobile_number", "$password", "$gmail", "$address", "$status", "$score", "$program", "$semester", "$dob", "$profile_photo", "$roll_no", "$gender", "$batch";

        if($program=="BIM"){
            
            $sql="SELECT * FROM batch_roll_no WHERE roll_no='$roll_no' AND batch='$batch'";
            $result=mysqli_query($db_bim,$sql);
            if(mysqli_num_rows($result)>0){
                
                // Check if user with the same mobile_number already exists
                $check_query = "SELECT * FROM students WHERE mobile_number = '$mobile_number' OR roll_no = '$roll_no'";
                $result = mysqli_query($db_bim, $check_query);
                if (mysqli_num_rows($result) > 0) {
                    echo'<script>
                    alert("User already exists!...");
                    window.location.href="../../index.php";
                    </script>';
                }
                // Check if user with the same roll_no already exists
                // $check_query = "SELECT * FROM first_semester WHERE roll_no = '$roll_no'";
                // $result2 = mysqli_query($db_bim, $check_query);
                // if (mysqli_num_rows($result2) > 0) {
                //     echo'<a href="../register.html">back</a><br>';
                //     die("User with the same roll_no already exists!.");
                // }

                // Upload the profile photo
                $target_dir = "../../upload_files/";
                $target_file_profile = $target_dir . basename($_FILES["image"]["name"]);
                if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file_profile)) {
                    die("Error uploading profile photo.");
                }

                // SQL query
                $sql1 = "INSERT INTO students (first_name, middle_name, last_name, mobile_number, password, gmail, address, status,program, semester, dob, profile_photo, roll_no, gender,batch)
                VALUES ('$first_name', '$middle_name', '$last_name', '$mobile_number', '$user_password', '$gmail', '$address', '$status','$program', '$semester', '$dob', '$profile_photo', '$roll_no', '$gender', '$batch')";
                $result1=mysqli_query($db_bim, $sql1);

                if ($result1) {
                    echo'<script>
                            alert("Your account was created successfully.");
                            window.location.href="../../index.php";
                            </script>';
                    mysqli_close($db_bim);
                }
                else{
                    echo "Error: " . $sql ." and <br>" . mysqli_error($db_bim);

                }
            }else{
                echo'<script>
                            alert("Your batch and roll_no doesnot exist.SORRY.");
                            window.location.href="../../index.php";
                            </script>';
            }                
            
        }
    }
    else{
        die("File uploads are missing.");
    }
    exit(); // Ensure no further code is executed 
}
?>
