<?php
    include_once("connection.php");
    session_start();
    if(!isset($_SESSION['student_data'])){
       
        header('location:../../index.php');

    }

?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result</title>
    <link rel="stylesheet" href="../../css/header.css">
    <link rel="stylesheet" href="../../css/footer.css">
    <link rel="stylesheet" href="../../css/body.css">
    <link rel="stylesheet" href="../../css/dashboard.css">
    
    <style>
        #submit-button{
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            box-shadow: 0px 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }
        ul{
            
            margin-left:10%;
            margin-right:10%;
        }
        
        li{
            background: #fff;
            border-radius:none;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            
        }

        .sticky {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000; /* Ensure the navbar is above other content */
        }
    </style>
</head>
<body style="margin:0px;">

    <div id="top-section">
        <header>
        <!-- <img src="../../upload_files/hdc.png" alt="HDC"> -->
            <h1>Digital Election Platform</h1>
            
        </header>
    </div>

    <div id="navbar" style="overflow: hidden; background-color: rgb(94, 75, 115); padding: 15px;text-align: center; box-sizing: border-box;">
        <nav>  
            <a href="dashboard.php">Home</a>
            <a href="candidates.php">Candidates</a>
            <a href="result.php" style="color: rgb(172, 166, 214);">Result</a>
            <a href="inbox.php">Students</a>
            <!-- <a href="about_us.php" >About us</a> -->
            <!-- <button onclick="window.location.href='dashboard.php'" style="float:left;">back</button>  -->
            <button onclick="window.location.href='session_destroy.php'" style="float:right;">Log out</button>
        </nav>
    </div> 
    
    
    <?php

    $result_status="SELECT * FROM result WHERE results='published'";
    $result_status1=mysqli_query($db_bim,$result_status);
    if(mysqli_num_rows($result_status1)>0){
        $user_semester_result="";
        $user_semester=$_SESSION['student_data']['semester'];
        while($result_array=mysqli_fetch_assoc($result_status1)){
            if($user_semester==$result_array['semester']){
                $vote=0;
                $draw="";
                $roll_no="xxxxx";
                $f_name="xxxxx";
                $l_name="xxxxx";
                $sql="SELECT * FROM candidates WHERE candidate_status='approved' AND semester='$user_semester'";
                $result= mysqli_query($db_bim,$sql);
                if($result){
                    if(mysqli_num_rows($result)>0){
                        $user_semester_result="complete";
                        while($row = mysqli_fetch_assoc($result)) {
                            if($row["vote"]>$vote){
                                $vote=$row["vote"];
                                $roll_no=$row["roll_no"];
                                $f_name=$row["first_name"];
                                $l_name=$row["last_name"];
                                $draw="";
                            }
                            else{
                                if($row["vote"]==$vote){
                                    $draw="draw";
                                }
                            }
                            
                        }
    
                        $sql_for_profile="SELECT profile_photo FROM students WHERE roll_no='$roll_no'";
                        $profile_result=mysqli_query($db_bim,$sql_for_profile);
                        if($profile_result){
                            if(mysqli_num_rows($profile_result)>0){
                                $row=mysqli_fetch_array($profile_result);
                                $profile=$row['profile_photo'];
                            }
                        }
    
                        if($draw!="draw"){
                            echo"
                            <div style='width:100%; text-align:center;display:block;'>
                                <img src='../../upload_files/$profile' alt='profile photo' style='margin-top:10px; width:100px; height:100px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                            </div>
                            <div style='width:100%;text-align:center;margin-top:10px;color:green;'><h3><i>Congratulation '$f_name $l_name' you have win the CR election of BIM fifth semester.</i></h3></div><hr>
                        
                            ";
                        }
                        else if($draw=="draw"){
                            echo"<div style='width:100%;text-align:center;margin-top:10px;color:green;'><h3><i>The Election is Draw.</i></h3></div><hr>";
            
                        }
                        else{
                            echo"All candidates have 0 votes.";
                        }

                        $total="SELECT * FROM students WHERE semester='$user_semester'";
                        $total=mysqli_query($db_bim,$total);
                        if(mysqli_num_rows($total)>0){
                            $total=mysqli_num_rows($total);
                        }

                        $all_candidates="SELECT * FROM candidates WHERE semester='$user_semester' AND candidate_status='approved'";
                        $all_result=mysqli_query($db_bim,$all_candidates);
            
                        if($all_result){
                            if(mysqli_num_rows($all_result)>0){
                                echo"<h3 style='margin-left:12%;'>Candidates :</h3>";
                                while($all_row=mysqli_fetch_assoc($all_result)){
                                    $roll_no=$all_row['roll_no'];
                                    $photo="SELECT profile_photo FROM students WHERE roll_no='$roll_no'";
                                    $photo=mysqli_query($db_bim,$photo);
                                    if($photo){
                                        if(mysqli_num_rows($photo)>0){
                                            $photo=mysqli_fetch_array($photo);
                                        }
                                    }
                                    
                                    echo"
                                    <ul>
                                        <li>
                                        <image src='../../upload_files/".$photo['profile_photo']."' style='float:right; margin-right:10px; margin-top:0px; width:100px; height:100px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'>
                                        <b><i> First Name : ". $all_row['first_name']. "<br>Last Name : " .$all_row['last_name']. "<br>"."Roll No. : ". $all_row['roll_no']."<br>".
                                        "Program : BIM <br> "."Semester : ".$all_row['semester']. "<br>"."Votes : ".$all_row['vote']."/$total <br></i></b>
                                        </li>
                                    </ul>
                                    ";
                                }
                            }
            
                        }
                    }
                    else{
                        $user_semester_result="published";
                        // echo"<div style='text-align:center;'><h2> No any elections were held, so result is not available..</h2></div>";
                    }
                }
            }else{
                // $user_semester_result='not-published';
                
            }

        }
        if($user_semester_result=='published'){
            echo"<div style='text-align:center;'><h2> No any elections were held for $user_semester semester , so result is not available..</h2></div>";
        }
        else if($user_semester_result=='complete'){

        }else{
            echo"<div style='text-align:center;'><h2> The result will be published soon for $user_semester semester.</h2></div>";
        
        }
    }else{
        echo"<div style='text-align:center;'><h2>The Result will be publish soon.</h2></div>";
    }
        
    ?>

    <div id="footer-section">
        <footer>
            Copyright © 2024, All rights reserved. <a>The Constructors.</a>
        </footer>
    </div>

    <script>
    // JavaScript to make navbar fixed when it reaches the top of the page
    window.onscroll = function() {fixNavbar()};

    var navbar = document.getElementById("navbar");
    var sticky = navbar.offsetTop;

    function fixNavbar() {
        if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky");
        } else {
        navbar.classList.remove("sticky");
        }
    }
    </script>

</body>
</html>